module.exports = {
  SIZES: [1, 2, 4, 6, 8, 12, 16, 20, 24, 28, 32],
};
