module.exports = {
  MAX_UINT48: 2n ** 48n - 1n,
  MAX_UINT64: 2n ** 64n - 1n,
};
