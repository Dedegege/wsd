---
'openzeppelin-solidity': minor
---

`Bytes`: Add a library of common operation that operate on `bytes` objects.
