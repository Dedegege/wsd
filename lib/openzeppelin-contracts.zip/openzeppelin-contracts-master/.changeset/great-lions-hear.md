---
'openzeppelin-solidity': patch
---

`VotesExtended`: Create an extension of `Votes` which checkpoints balances and delegates.
