---
'openzeppelin-solidity': minor
---

`CAIP2` and `CAIP10`: Add libraries for formatting and parsing CAIP-2 and CAIP-10 identifiers.
