---
'openzeppelin-solidity': patch
---

`GovernorCountingOverridable`: Add a governor counting module that enables token holders to override the vote of their delegate.
